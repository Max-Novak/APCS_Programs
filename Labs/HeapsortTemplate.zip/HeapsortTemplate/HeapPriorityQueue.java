import java.util.*;

/**
 * This class implements the PriorityQueue interface using
 * a binary heap.
 *
 * the basic idea is that the node whose index is k
 * has children stored with indexes 2*k and 2*k+1 for left/right
 * children, respectively. The root of the binary heap has index 1.
 *
 * @author Your Name
 */

public class HeapPriorityQueue implements PriorityQueue
{
  private List items;
  private int mySize;

  /**
   * Constructs an empty priority queue.
   */
  public HeapPriorityQueue()
  {
    items = new ArrayList();
    items.add(null);            // first add should go at index 1
    mySize = 0;
  }

  public void add(Object obj)
  {
    System.out.println("add " + obj);
  }

  public Object removeMin()
  {
    throw new NoSuchElementException();
  }

  public Object peekMin()
  {
    throw new NoSuchElementException();
  }

  public boolean isEmpty()
  {
    return true;
  }

  /**
   * preconditon: subheaps of hroot satisfy heap property (and shape)
   * postcondition: heap rooted at hroot satisfies heap property
   */
  private void heapify(int hroot)
  {
    System.out.println("heapify " + hroot);
  }
}
